let handler = async (m, { conn, text, usedPrefix, command }) => {
  m.reply(wait)
await m.reply("Berhasil... Eits Tidak boleh begitu dosa")
}
handler.help = ["mutilasi"]
handler.tags = ["rpg"]
handler.command = ["mutilasi"]
module.exports = handler